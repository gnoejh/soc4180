"""Promoted law code (epi): copied unchanged from the research engine."""
