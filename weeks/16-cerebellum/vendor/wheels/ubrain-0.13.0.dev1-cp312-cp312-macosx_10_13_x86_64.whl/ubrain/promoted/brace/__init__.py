"""Promoted law code (brace): copied unchanged from the research engine."""
