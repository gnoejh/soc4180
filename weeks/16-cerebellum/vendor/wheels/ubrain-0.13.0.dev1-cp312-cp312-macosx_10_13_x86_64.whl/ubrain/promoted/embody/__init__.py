"""Promoted law code (embody): copied unchanged from the research engine."""
