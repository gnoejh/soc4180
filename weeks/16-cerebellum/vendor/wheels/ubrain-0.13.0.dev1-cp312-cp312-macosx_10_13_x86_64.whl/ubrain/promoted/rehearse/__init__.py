"""Promoted law code (rehearse): copied unchanged from the research engine."""
