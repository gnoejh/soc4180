"""Promoted law code (bg): copied unchanged from the research engine."""
