"""Promoted law code (cortex): copied unchanged from the research engine."""
