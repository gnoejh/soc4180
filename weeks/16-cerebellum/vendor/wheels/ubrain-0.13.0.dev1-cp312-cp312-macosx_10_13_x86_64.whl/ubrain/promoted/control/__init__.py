"""Promoted law code (control): copied unchanged from the research engine."""
