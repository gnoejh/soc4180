"""Promoted law code (cbl): copied unchanged from the research engine."""
