"""Promoted law code (dstr): copied unchanged from the research engine."""
