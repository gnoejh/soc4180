"""Promoted law code (lang): copied unchanged from the research engine."""
