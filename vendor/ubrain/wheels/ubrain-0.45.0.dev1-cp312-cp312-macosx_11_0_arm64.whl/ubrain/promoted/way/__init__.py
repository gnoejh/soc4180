"""Promoted law code (way): copied unchanged from the research engine."""
