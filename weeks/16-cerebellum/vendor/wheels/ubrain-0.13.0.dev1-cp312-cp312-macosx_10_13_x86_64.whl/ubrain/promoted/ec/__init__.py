"""Promoted law code (ec): copied unchanged from the research engine."""
