"""Codec extras: wrappers for frozen AI models, each behind its own pip extra so the
brain itself never needs torch. `pip install ubrain[vision]` -> ubrain.extras.clip."""
