"""ubrain -- Untrained Brain: never trained, always learning.

A modality-general brain that learns from experience by local plasticity. Plug in
any AI encoder as its senses and any body as its interface.

    from ubrain import Brain, profile, manifest_from_hello_03
    brain = Brain(profile("walker"), manifest)
    actions = brain.tick({"proprio": ..., "tone": False, "goal": (0.5, 0.0, 0.0)})

Pre-release (0.13.0.dev1; codecs and their certificates since 0.3, the hippocampal
episode and the `observer` profile since 0.4, CLIP as the `vision` extra since 0.5,
the `explorer` profile and recognising senses since 0.6, the memory system -- the
cortical slow store, replay into it, the `rememberer` profile -- since 0.7, working
memory -- the prefrontal buffer, rehearsal, the `holder` profile -- since 0.8,
noticing and switching -- the salience gate, the mode controller, consolidation on
idle, the `attender` profile -- since 0.9, episodic control -- the hippocampal store
that acts, the hand-over to the striatum, the `chooser` profile -- since 0.10, the hubs
-- the thalamic relay, acetylcholine, noradrenaline and serotonin as scalars on existing
knobs, the `modulated` profile -- since 0.11, walking adaptation -- one learning rate or
two, the after-effect, savings and spontaneous recovery, the `adapter` profile -- since
0.12, a Gymnasium game as a body -- `ubrain.bodies.gym`, the `game` extra -- since 0.13): a
generic brain -- regions with typed ports, the wiring as a dataflow -- running two anatomies on two bodies with no brain code between
them: `walker` (the G1, contract 1.0 over protocol 0.3) and `player` (any body
that shows a situation and pays a reward: a bandit, or a Gymnasium game through
ubrain.bodies.gym). The laws behind every region are in The Untrained Brain Series,
Volume 1; how this package is built, in Volume 2.
"""

from ubrain.brain import Brain
from ubrain.contract import (CONTRACT_VERSION, Channel, Manifest, act_03, manifest_from_hello_03,
                             senses_from_state_03)
from ubrain.wiring import Wiring, load, profile
from ubrain.codecs import Certificate, Codec, FrozenCodes, GaussianCodes, Sense, certify

__version__ = "0.13.0.dev1"

__all__ = ["Brain", "Channel", "Manifest", "Wiring", "CONTRACT_VERSION", "load", "profile",
           "Codec", "FrozenCodes", "GaussianCodes", "Sense", "Certificate", "certify",
           "manifest_from_hello_03", "senses_from_state_03", "act_03", "__version__"]
