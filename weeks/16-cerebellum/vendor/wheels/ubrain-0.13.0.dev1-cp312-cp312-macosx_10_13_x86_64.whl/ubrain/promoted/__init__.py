"""Promoted regions: law code copied unchanged from the research engine where each law
was measured. Never edited here; a change is measured there and copied again."""
