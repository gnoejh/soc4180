"""Promoted law code (assoc): copied unchanged from the research engine."""
