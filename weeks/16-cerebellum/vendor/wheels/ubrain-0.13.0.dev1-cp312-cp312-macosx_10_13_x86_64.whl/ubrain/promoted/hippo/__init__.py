"""Promoted law code (hippo): copied unchanged from the research engine."""
