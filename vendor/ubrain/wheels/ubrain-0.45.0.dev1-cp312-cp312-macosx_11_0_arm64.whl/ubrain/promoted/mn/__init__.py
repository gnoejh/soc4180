"""Promoted law code (mn): copied unchanged from the research engine."""
