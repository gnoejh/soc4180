"""Promoted law code (adapt): copied unchanged from the research engine."""
