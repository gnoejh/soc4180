"""Promoted law code (cls): copied unchanged from the research engine."""
